package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.main;

import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;


import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.MainController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.UserController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Base;

public class MainForm extends Base {

    private Button addUserButton;
    private MainController mainController;

    public MainForm(MainController context) {
        super(context);
        this.mainController = context;
        this.initLayout();
        this.initListeners();
    }

    @Override
    public void initListeners() {

        this.addUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("MainFrom", "Button clicked!!");

                    Intent intent = new Intent(view.getContext(), UserController.class);

                    view.getContext().startActivity(intent);
            }
        });

    }


    private void initLayout() {
        final LinearLayout addMainLayout = new LinearLayout(this.getContext());
        addMainLayout.setOrientation(LinearLayout.HORIZONTAL);

        addMainLayout.addView(this.initAddUserButton());

        this.setContainer(addMainLayout);
    }

    private Button initAddUserButton() {
        this.addUserButton = new Button(this.getContext());
        this.addUserButton.setText("Create New User");
        this.addUserButton.setTextColor(Color.WHITE);
        this.addUserButton.setBackgroundColor(Color.DKGRAY);

        return this.addUserButton;
    }


}
