package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.main;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.R;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.models.User;

public class MainView extends LinearLayout {

    private TextView userTextView;

    public MainView(Context context, final User user) {
        super(context);

        final LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        inflater.inflate(R.layout.user_view, this, true);

        this.userTextView = this.findViewById(R.id.userTextView);
        this.userTextView.setText(user.toString());

    }


}
