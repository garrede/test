package dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.util.List;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.lib.dao.UserDao;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.models.User;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.containers.MainContainer;

public class MainController extends AppCompatActivity {

    private MainContainer container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.container = new MainContainer(this);
        this.container.render();
    }

    public List <User> getAllUsers() {
        UserDao userDao = new UserDao(this);
        return userDao.find_all();
    }

}
