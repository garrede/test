package dsarauer9.cvtc.edu.finalprojectdsarauer9.lib.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Helper extends SQLiteOpenHelper {

    public static final Integer DB_VERSION  = 1;
    public static final String DB_NAME = "dsarauer9.cvtc.edu.finalprojectdsarauer9";

    public static final String USERS_TABLE_NAME = "users";
    public static final String USERS_COLUMN_ID = "id";
    public static final String USERS_COLUMN_NAME = "name";

    public Helper(Context context) { super(context, DB_NAME, null,  DB_VERSION); }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = String.format("CREATE TABLE %s (%s integer primary key, %s text)",
                USERS_TABLE_NAME, USERS_COLUMN_ID, USERS_COLUMN_NAME
        );
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(String.format("DROP TABLE IF EXISTS %s", USERS_TABLE_NAME));
        this.onCreate(db);
    }

}
