package dsarauer9.cvtc.edu.finalprojectdsarauer9.lib.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.lib.sqlite.Helper;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.models.User;

public class UserDao extends Base implements iDao<User> {

    public UserDao(Context context) { super(context); }

    public User find(long id) { return null; }

    public List<User> find_all() {
        List<User> users = new ArrayList<>();

        SQLiteDatabase db = this.getDbHelper().getReadableDatabase();
        Cursor res = db.rawQuery(
                String.format("SELECT * FROM %s", Helper.USERS_TABLE_NAME), null
        );

        res.moveToFirst();

        while (!res.isAfterLast()) {
            users.add(new User(
                    res.getInt(res.getColumnIndex(Helper.USERS_COLUMN_ID)),
                    res.getString(res.getColumnIndex(Helper.USERS_COLUMN_NAME))
            ));
            res.moveToNext();
        }
        return users;
    }

    public User save(User u) {

        SQLiteDatabase db = this.getDbHelper().getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(Helper.USERS_COLUMN_NAME, u.getName());

        long id = db.insert(Helper.USERS_TABLE_NAME, null, cv);
        u.setId(id);

        return u;

    }

    public User update(User u) { return null; }

    public User delete(User u) {
        String where = Helper.USERS_COLUMN_ID + "= ?";
        String [] whereArgs = { String.valueOf(u) };

        SQLiteDatabase db = this.getDbHelper().getWritableDatabase();
        db.delete(Helper.USERS_TABLE_NAME, where, whereArgs);
        db.close();
        return u;
    }

}
