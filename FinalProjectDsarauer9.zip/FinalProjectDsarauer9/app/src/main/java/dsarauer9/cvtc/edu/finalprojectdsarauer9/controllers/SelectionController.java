package dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.containers.SelectionContainer;

public class SelectionController extends AppCompatActivity {

    private SelectionContainer container;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.container = new SelectionContainer(this);
        this.container.render();
    }
}
