package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.containers;

import android.util.Log;
import android.widget.LinearLayout;

import java.util.List;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.MainController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.models.User;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Base;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.main.MainForm;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.main.MainList;

public class MainContainer extends Base {

    private MainForm mainForm;
    private MainList mainList;

    public MainContainer(MainController context) {
        super(context);

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);

        this.mainForm = new MainForm(context);
        this.mainList = new MainList(context);

        List<User> userList = context.getAllUsers();
        for(User user : userList) {
            this.mainList.addUser(user);
        }

        layout.addView(this.mainForm.getContainer());
        layout.addView(this.mainList.getContainer());

        this.setContainer(layout);
    }

}