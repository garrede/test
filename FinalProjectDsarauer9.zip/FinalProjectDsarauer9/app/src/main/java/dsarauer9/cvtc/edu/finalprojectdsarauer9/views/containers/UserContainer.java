package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.containers;

import android.widget.LinearLayout;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.UserController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Base;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.user.UserForm;

public class UserContainer extends Base {

    private UserForm userForm;

    public UserContainer(UserController context) {
        super(context);

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);

        this.userForm = new UserForm(context);

        layout.addView(this.userForm.getContainer());

        this.setContainer(layout);
    }

}
