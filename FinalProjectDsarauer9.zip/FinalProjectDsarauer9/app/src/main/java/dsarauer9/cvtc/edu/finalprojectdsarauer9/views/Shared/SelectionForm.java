package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Shared;

import android.graphics.Color;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.SelectionController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Base;

public class SelectionForm extends Base {

    private TextView name;

    private Button addition;
    private Button subtraction;
    private Button delete;
    private SelectionController controller;

    public SelectionForm(SelectionController context){
        super(context);
        this.controller = context;
        this.initLayout();
    }

    private void initLayout() {
        final LinearLayout selectionLayout = new LinearLayout(this.getContext());
        selectionLayout.setOrientation(LinearLayout.VERTICAL);

        selectionLayout.addView(this.initTextView());
        selectionLayout.addView(this.initAdditionButton());
        selectionLayout.addView(this.initSubtractionButton());
        selectionLayout.addView(this.initDeleteButton());

        this.setContainer(selectionLayout);
    }

    private Button initAdditionButton() {
        this.addition = new Button(this.getContext());
        this.addition.setText("Addition");
        this.addition.setTextColor(Color.BLUE);
        this.addition.setBackgroundColor(Color.YELLOW);

        return this.addition;
    }

    private Button initSubtractionButton() {
        this.subtraction = new Button(this.getContext());
        this.subtraction.setText("Subtraction");
        this.subtraction.setTextColor(Color.BLUE);
        this.subtraction.setBackgroundColor(Color.YELLOW);

        return this.subtraction;
    }

    private Button initDeleteButton() {
        this.delete = new Button(this.getContext());
        this.delete.setText("Delete");
        this.delete.setTextColor(Color.DKGRAY);
        this.delete.setBackgroundColor(Color.LTGRAY);

        return this.delete;
    }

    private TextView initTextView() {
        this.name = new TextView(this.getContext());

        return this.name;
    }


}
