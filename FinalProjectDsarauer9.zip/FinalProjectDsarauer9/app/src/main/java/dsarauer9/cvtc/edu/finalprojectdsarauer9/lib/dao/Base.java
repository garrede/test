package dsarauer9.cvtc.edu.finalprojectdsarauer9.lib.dao;

import android.content.Context;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.lib.sqlite.Helper;

public class Base {

    protected Context context;
    protected Helper dbHelper;

    public Base(Context context) {
        this.context = context;
        this.dbHelper = new Helper(context);
    }

    public Helper getDbHelper() { return this.dbHelper; }
}
