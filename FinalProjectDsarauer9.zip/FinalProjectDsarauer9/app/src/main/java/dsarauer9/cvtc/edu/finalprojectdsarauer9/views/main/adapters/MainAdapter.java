package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.main.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.List;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.models.User;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.main.MainView;

public class MainAdapter extends BaseAdapter {

    private Context context;
    private List<User> userList;

    public MainAdapter(final Context context, List<User> userList) {
        this.context = context;
        this.userList = userList;
    }

    @Override
    public int getCount() { return this.userList != null ? this.userList.size() : 0; }

    @Override
    public Object getItem(int position) {
        return this.userList != null ? this.userList.get(position) : null;
    }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final User user = this.userList.get(position);
        return new MainView(this.context, user);
    }




}
