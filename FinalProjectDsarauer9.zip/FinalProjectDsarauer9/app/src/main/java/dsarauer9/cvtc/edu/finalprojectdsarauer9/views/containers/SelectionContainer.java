package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.containers;

import android.widget.LinearLayout;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.SelectionController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Base;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Shared.SelectionForm;

public class SelectionContainer extends Base {

    private SelectionForm selectionForm;

    public SelectionContainer(SelectionController context) {
        super(context);

        LinearLayout layout = new LinearLayout(context);

        this.selectionForm = new SelectionForm(context);

        layout.addView(this.selectionForm.getContainer());

        this.setContainer(layout);
    }


}
