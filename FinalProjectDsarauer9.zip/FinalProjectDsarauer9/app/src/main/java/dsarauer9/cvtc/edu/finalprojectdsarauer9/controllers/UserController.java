package dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.lib.dao.UserDao;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.models.User;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.containers.MainContainer;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.containers.UserContainer;

public class UserController extends AppCompatActivity {

    private UserContainer container;
    private MainContainer mainContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.container = new UserContainer(this);
        this.container.render();
    }

    public void saveUserFromEditText(String user) {
        if (user != null && !user.isEmpty()) {
            UserDao userDao = new UserDao(this);
            userDao.save(new User(user));
            return;
        }
        Toast.makeText(this, "The name was empty. Please enter a name", Toast.LENGTH_LONG).show();
    }

}
