package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.main;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;


import java.util.ArrayList;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.SelectionController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.models.User;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Base;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.main.adapters.MainAdapter;

public class MainList extends Base {

    private ArrayList<User> userList = new ArrayList<>();
    private MainAdapter adapter;

    public User user;

    public MainList(Context context) {
        super(context);
        this.adapter = new MainAdapter(context, this.userList);

        ListView userListView = new ListView(context);

        userListView.setClickable(true);
        userListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(view.getContext(), SelectionController.class);

                view.getContext().startActivity(intent);

                MainList.this.user = (User) adapterView.getItemAtPosition(i);
            }
        });

        userListView.setAdapter(this.adapter);

        this.setContainer(userListView);

        this.initListeners();
    }

    public void addUser(final User user) {
        this.userList.add(user);
        this.adapter.notifyDataSetChanged();
    }
}
