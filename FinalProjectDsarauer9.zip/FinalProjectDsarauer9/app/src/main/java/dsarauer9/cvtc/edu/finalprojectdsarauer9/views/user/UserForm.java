package dsarauer9.cvtc.edu.finalprojectdsarauer9.views.user;

import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.MainController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.controllers.UserController;
import dsarauer9.cvtc.edu.finalprojectdsarauer9.views.Base;

public class UserForm extends Base {

    private Button createUser;
    private EditText nameEditText;
    private UserController userController;

    public UserForm(UserController context) {
        super(context);
        this.userController = context;
        this.initLayout();
        this.initListeners();
    }

    @Override
    public void initListeners() {

        Log.d("UserForm", "UserButton");

        this.createUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String nameText = nameEditText.getText().toString().trim();

                userController.saveUserFromEditText(nameText);

                Intent intent = new Intent(view.getContext(), MainController.class);
                view.getContext().startActivity(intent);
            }
        });
    }

    private void initLayout() {
        final LinearLayout createUserLayout = new LinearLayout(this.getContext());
        createUserLayout.setOrientation(LinearLayout.VERTICAL);

        createUserLayout.addView(this.initNameText());
        createUserLayout.addView(this.initAddUserButton());

        this.setContainer(createUserLayout);
    }

    private EditText initNameText() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );

        this.nameEditText = new EditText(this.getContext());
        this.nameEditText.setLayoutParams(params);

        return this.nameEditText;
    }

    private Button initAddUserButton() {
        this.createUser = new Button(this.getContext());
        this.createUser.setText("Save User");
        this.createUser.setTextColor(Color.WHITE);
        this.createUser.setBackgroundColor(Color.DKGRAY);

        return this.createUser;
    }


}
