package dsarauer9.cvtc.edu.finalprojectdsarauer9.lib.dao;

import java.util.List;

public interface iDao<T> {

    T find(long id);
    List<T> find_all();

    T save(T t);
    T update(T t);
    T delete(T t);

}
